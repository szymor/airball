
#define	FPS_1S	(60)

// Prototypes.
void FrameInit(void);
void FrameWait(void);

extern u32	gnFrame;
