
// Prototypes.
void FontPrint16(SDL_Surface *pDstSurf, SDL_Surface *pFont, s32 nPosX, s32 nPosY, char *pStr, u32 nPalNo);
void MyItoA(u32 nNb, char *pDst);

void Font_CreateTxtColors(u8 r1, u8 g1, u8 b1, u8 r2, u8 g2, u8 b2, u8 nPalNo);

